const menuItems = [
    { name: "Exotic Breakfast Platter", type: "Breakfast", price: 9.99, image: "exotic_breakfast.jpg" },
    { name: "Blueberry Pancakes", type: "Breakfast", price: 8.99, image: "blueberry_pancakes.jpg" },
    { name: "Avocado Toast", type: "Breakfast", price: 10.99, image: "avocado_toast.jpg" },
    { name: "Tropical Mango Salad", type: "Lunch", price: 12.99, image: "salad.jpg" },
    { name: "Chicken Caesar Wrap", type: "Lunch", price: 11.99, image: "caesar_wrap.jpg" },
    { name: "Vegetable Sushi Roll", type: "Lunch", price: 13.99, image: "vegetable_sushi.jpg" },
    { name: "Spicy Coconut Curry", type: "Dinner", price: 14.99, image: "coconut_curry.jpg" },
    { name: "Grilled Salmon", type: "Dinner", price: 16.99, image: "grilled_salmon.jpg" },
    { name: "Beef Stir-Fry", type: "Dinner", price: 15.99, image: "beef_stir_fry.jpg" },
    { name: "Chocolate Lava Cake", type: "Dessert", price: 7.99, image: "chocolate_lava_cake.jpg" },
    { name: "Fruit Tart", type: "Dessert", price: 6.99, image: "fruit_tart.jpg" },
    { name: "Tiramisu", type: "Dessert", price: 8.99, image: "tiramisu.jpg" }
];

const menuSection = document.getElementById("menu");
const placeOrderSection = document.getElementById("place-order");

// Function to dynamically generate menu items
function generateMenu() {
    // Separate the menu items by type
    const breakfastItems = menuItems.filter(item => item.type === "Breakfast");
    const lunchItems = menuItems.filter(item => item.type === "Lunch");
    const dinnerItems = menuItems.filter(item => item.type === "Dinner");
    const dessertItems = menuItems.filter(item => item.type === "Dessert");

    // Helper function to create a menu section
    function createMenuSection(title, items) {
        const section = document.createElement("div");
        section.classList.add("menu-section");

        const sectionTitle = document.createElement("h2");
        sectionTitle.textContent = title;
        if (title !== "Breakfast") { // If the title is not "Breakfast"
            sectionTitle.style.textDecoration = "underline double"; // Add double underline
        }
        section.appendChild(sectionTitle);

        items.forEach(item => {
            const menuItem = document.createElement("div");
            menuItem.classList.add("menu-item");

            const itemName = document.createElement("h3");
            itemName.textContent = item.name;

            const itemPrice = document.createElement("p");
            itemPrice.textContent = `$${item.price.toFixed(2)}`; // Display price with 2 decimal places

            const itemImage = document.createElement("img");
            itemImage.src = item.image;
            itemImage.alt = item.name;
            itemImage.style.width = "100px"; // Set width to 100px
            itemImage.style.height = "100px"; // Set height to 100px

            const quantityInput = document.createElement("input");
            quantityInput.type = "number";
            quantityInput.min = "0";
            quantityInput.placeholder = "Quantity";

            menuItem.appendChild(itemImage);
            menuItem.appendChild(itemName);
            menuItem.appendChild(itemPrice);
            menuItem.appendChild(quantityInput);

            section.appendChild(menuItem);

            // Event listener to calculate total on quantity change
            quantityInput.addEventListener('input', () => {
                updateTotal();
            });
        });

        menuSection.appendChild(section);
    }

    // Generate menu sections for each meal type
    createMenuSection("Breakfast", breakfastItems);
    createMenuSection("Lunch", lunchItems);
    createMenuSection("Dinner", dinnerItems);
    createMenuSection("Dessert", dessertItems);
}

// Function to update the total cost
function updateTotal() {
    let total = 0;
    document.querySelectorAll('.menu-item').forEach(item => {
        const price = parseFloat(item.querySelector('p').textContent.replace('$', ''));
        const quantity = parseInt(item.querySelector('input').value);
        total += price * (isNaN(quantity) ? 0 : quantity);
    });
    document.getElementById('total-cost').textContent = `$${total.toFixed(2)}`;
}

// Call the function to generate the menu on page load
generateMenu();

// Place Order Section
const placeOrderButton = document.createElement("button");
placeOrderButton.textContent = "Place Order";
placeOrderButton.addEventListener("click", () => {
    alert("Your order has been placed!");
});
placeOrderSection.appendChild(placeOrderButton);
